using FluentAssertions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using RaceDayAPI.Controllers;
using RaceDayAPI.DTOs.Auth;
using RaceDayAPI.Helpers;
using RaceDayAPI.Services.Implementations;
using RaceDayAPI.Tests.Helpers;
using Xunit;

namespace RaceDayAPI.Tests.Controllers
{
    public class AuthControllerTests
    {
        [Fact]
        public async Task Register_WithValidData_Returns201()
        {
            // Arrange
            using var context = TestDbContextFactory.Create();
            var jwtHelper = new JwtHelper(GetConfig());
            var service = new AuthService(context, jwtHelper);
            var controller = new AuthController(service);

            var dto = new RegisterDto
            {
                Email = "test@test.com",
                Password = "Password123",
                FullName = "Test User",
                Role = RoleConstants.Participant
            };

            // Act
            var result = await controller.Register(dto);

            // Assert
            result.Should().BeOfType<CreatedAtActionResult>();
        }

        [Fact]
        public async Task Register_WithDuplicateEmail_Returns409()
        {
            // Arrange
            using var context = TestDbContextFactory.Create();
            TestDataSeeder.SeedUsers(context);
            var jwtHelper = new JwtHelper(GetConfig());
            var service = new AuthService(context, jwtHelper);
            var controller = new AuthController(service);

            var dto = new RegisterDto
            {
                Email = "organiser@test.com",
                Password = "Password123",
                FullName = "Test",
                Role = RoleConstants.Participant
            };

            // Act
            var result = await controller.Register(dto);

            // Assert
            result.Should().BeOfType<ConflictObjectResult>();
        }

        [Fact]
        public async Task Login_WithValidCredentials_Returns200()
        {
            // Arrange
            using var context = TestDbContextFactory.Create();
            TestDataSeeder.SeedUsers(context);
            var jwtHelper = new JwtHelper(GetConfig());
            var service = new AuthService(context, jwtHelper);
            var controller = new AuthController(service);

            var dto = new LoginDto
            {
                Email = "organiser@test.com",
                Password = "Password123"
            };

            // Act
            var result = await controller.Login(dto);

            // Assert
            result.Should().BeOfType<OkObjectResult>();
        }

        [Fact]
        public async Task Login_WithInvalidCredentials_Returns401()
        {
            // Arrange
            using var context = TestDbContextFactory.Create();
            TestDataSeeder.SeedUsers(context);
            var jwtHelper = new JwtHelper(GetConfig());
            var service = new AuthService(context, jwtHelper);
            var controller = new AuthController(service);

            var dto = new LoginDto
            {
                Email = "organiser@test.com",
                Password = "WrongPassword"
            };

            // Act
            var result = await controller.Login(dto);

            // Assert
            result.Should().BeOfType<UnauthorizedObjectResult>();
        }

        private static IConfiguration GetConfig()
        {
            return new ConfigurationBuilder()
                .AddInMemoryCollection(new Dictionary<string, string>
                {
                    { "Jwt:Key", "SuperSecretKeyForRaceDaySystem12345678901234567890" },
                    { "Jwt:Issuer", "RaceDayAPI" },
                    { "Jwt:Audience", "RaceDayClient" },
                    { "Jwt:ExpiryHours", "1" }
                })
                .Build();
        }
    }
}