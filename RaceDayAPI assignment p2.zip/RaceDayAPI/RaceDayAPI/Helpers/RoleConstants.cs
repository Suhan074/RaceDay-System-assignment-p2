namespace RaceDayAPI.Helpers
{
    /// <summary>
    /// Constants for role names to avoid typos
    /// </summary>
    public static class RoleConstants
    {
        public const string Organiser = "Organiser";
        public const string Participant = "Participant";
        public const string OrganiserOrParticipant = "Organiser,Participant";
    }

    /// <summary>
    /// Constants for all status values in the system
    /// </summary>
    public static class StatusConstants
    {
        public static class EventStatus
        {
            public const string Upcoming = "Upcoming";
            public const string Ongoing = "Ongoing";
            public const string Completed = "Completed";
            public const string Cancelled = "Cancelled";
        }

        public static class EnrolmentStatus
        {
            public const string Pending = "Pending";
            public const string Confirmed = "Confirmed";
            public const string Cancelled = "Cancelled";
        }

        public static class PaymentStatus
        {
            public const string Pending = "Pending";
            public const string Paid = "Paid";
            public const string Refunded = "Refunded";
        }

        public static class ResultStatus
        {
            public const string DNS = "DNS";
            public const string DNF = "DNF";
            public const string Finished = "Finished";
            public const string Disqualified = "Disqualified";
        }

        public static class EventType
        {
            public const string Run = "Run";
            public const string Walk = "Walk";
            public const string Cycle = "Cycle";
        }

        public static class GenderRestriction
        {
            public const string None = "None";
            public const string Male = "Male";
            public const string Female = "Female";
        }
    }
}