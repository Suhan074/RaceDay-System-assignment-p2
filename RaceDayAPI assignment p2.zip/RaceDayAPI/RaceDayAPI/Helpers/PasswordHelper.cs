using BCrypt.Net;

namespace RaceDayAPI.Helpers
{
    /// <summary>
    /// Handles password hashing and verification using BCrypt
    /// </summary>
    public static class PasswordHelper
    {
        /// <summary>
        /// Hash a plain text password using BCrypt
        /// </summary>
        public static string HashPassword(string plainPassword)
        {
            if (string.IsNullOrWhiteSpace(plainPassword))
                throw new ArgumentException("Password cannot be empty", nameof(plainPassword));

            return BCrypt.Net.BCrypt.HashPassword(plainPassword, workFactor: 12);
        }

        /// <summary>
        /// Verify a plain text password against a stored hash
        /// </summary>
        public static bool VerifyPassword(string plainPassword, string hashedPassword)
        {
            if (string.IsNullOrWhiteSpace(plainPassword) || string.IsNullOrWhiteSpace(hashedPassword))
                return false;

            try
            {
                return BCrypt.Net.BCrypt.Verify(plainPassword, hashedPassword);
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Check if a password meets strength requirements
        /// (at least 8 chars, one uppercase, one lowercase, one number)
        /// </summary>
        public static bool IsStrongPassword(string password)
        {
            if (string.IsNullOrWhiteSpace(password) || password.Length < 8)
                return false;

            bool hasUpper = password.Any(char.IsUpper);
            bool hasLower = password.Any(char.IsLower);
            bool hasDigit = password.Any(char.IsDigit);

            return hasUpper && hasLower && hasDigit;
        }

        /// <summary>
        /// Get a user-friendly message explaining password requirements
        /// </summary>
        public static string GetPasswordRequirements()
        {
            return "Password must be at least 8 characters with at least " +
                   "one uppercase letter, one lowercase letter, and one number.";
        }
    }
}