using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using RaceDayAPI.Data;
using RaceDayAPI.Models;

namespace RaceDayAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class EnrolmentsController : ControllerBase
    {
        private readonly RaceDayDbContext _context;

        public EnrolmentsController(RaceDayDbContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Enrol in a category (Participant only)
        /// </summary>
        [HttpPost]
        [Authorize(Roles = "Participant")]
        public async Task<IActionResult> Enrol([FromBody] CreateEnrolmentDto dto)
        {
            var participantId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");

            var category = await _context.Categories
                .Include(c => c.Event)
                .FirstOrDefaultAsync(c => c.CategoryID == dto.CategoryId);

            if (category == null)
                return NotFound(new { message = "Category not found" });

            if (category.Event.Status == "Completed" || category.Event.Status == "Cancelled")
                return BadRequest(new { message = "Event is no longer accepting enrolments" });

            // Check if already enrolled
            if (_context.Enrolments.Any(e => e.ParticipantID == participantId && e.CategoryID == dto.CategoryId))
                return Conflict(new { message = "Already enrolled in this category" });

            // Check if event is full
            var currentCount = await _context.Enrolments
                .Where(e => e.Category.EventID == category.EventID && e.Status != "Cancelled")
                .CountAsync();

            if (currentCount >= category.Event.MaxParticipants)
                return Conflict(new { message = "Event is full" });

            var enrolment = new Enrolment
            {
                ParticipantID = participantId,
                CategoryID = dto.CategoryId,
                EnrolmentDate = DateTime.UtcNow,
                Status = "Pending",
                PaymentStatus = "Pending",
                UpdatedAt = DateTime.UtcNow
            };

            _context.Enrolments.Add(enrolment);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetEnrolment), new { id = enrolment.EnrolmentID }, enrolment);
        }

        /// <summary>
        /// Get current user's enrolments (Participant only)
        /// </summary>
        [HttpGet("participant")]
        [Authorize(Roles = "Participant")]
        public async Task<IActionResult> GetMyEnrolments()
        {
            var participantId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");

            var enrolments = await _context.Enrolments
                .Include(e => e.Category)
                    .ThenInclude(c => c.Event)
                .Include(e => e.Result)
                .Where(e => e.ParticipantID == participantId)
                .Select(e => new
                {
                    e.EnrolmentID,
                    EventName = e.Category.Event.EventName,
                    EventDate = e.Category.Event.EventDate,
                    CategoryName = e.Category.CategoryName,
                    e.EnrolmentDate,
                    e.Status,
                    e.PaymentStatus,
                    HasResult = e.Result != null
                })
                .ToListAsync();

            return Ok(enrolments);
        }

        /// <summary>
        /// Get enrolment by ID
        /// </summary>
        [HttpGet("{id}")]
        public async Task<IActionResult> GetEnrolment(int id)
        {
            var enrolment = await _context.Enrolments
                .Include(e => e.Category)
                    .ThenInclude(c => c.Event)
                .Include(e => e.Participant)
                .FirstOrDefaultAsync(e => e.EnrolmentID == id);

            if (enrolment == null)
                return NotFound(new { message = "Enrolment not found" });

            var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
            var userRole = User.FindFirst(ClaimTypes.Role)?.Value ?? "";

            if (userRole != "Organiser" && enrolment.ParticipantID != userId)
                return StatusCode(403, new { message = "Access denied" });

            return Ok(enrolment);
        }

        /// <summary>
        /// Update enrolment status (Organiser only)
        /// </summary>
        [HttpPut("{id}/status")]
        [Authorize(Roles = "Organiser")]
        public async Task<IActionResult> UpdateStatus(int id, [FromBody] UpdateEnrolmentStatusDto dto)
        {
            var enrolment = await _context.Enrolments
                .Include(e => e.Category)
                    .ThenInclude(c => c.Event)
                .FirstOrDefaultAsync(e => e.EnrolmentID == id);

            if (enrolment == null)
                return NotFound(new { message = "Enrolment not found" });

            var organiserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
            if (enrolment.Category.Event.OrganiserID != organiserId)
                return StatusCode(403, new { message = "Not your event" });

            enrolment.Status = dto.Status;
            enrolment.UpdatedAt = DateTime.UtcNow;

            await _context.SaveChangesAsync();
            return Ok(enrolment);
        }

        /// <summary>
        /// Cancel enrolment (Participant only)
        /// </summary>
        [HttpDelete("{id}")]
        [Authorize(Roles = "Participant")]
        public async Task<IActionResult> CancelEnrolment(int id)
        {
            var enrolment = await _context.Enrolments.FindAsync(id);
            if (enrolment == null)
                return NotFound(new { message = "Enrolment not found" });

            var participantId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
            if (enrolment.ParticipantID != participantId)
                return StatusCode(403, new { message = "Not your enrolment" });

            if (enrolment.Status == "Confirmed")
                return BadRequest(new { message = "Cannot cancel confirmed enrolment" });

            _context.Enrolments.Remove(enrolment);
            await _context.SaveChangesAsync();
            return NoContent();
        }

        /// <summary>
        /// Get all enrolments for an event (Organiser only)
        /// </summary>
        [HttpGet("event/{eventId}")]
        [Authorize(Roles = "Organiser")]
        public async Task<IActionResult> GetEventEnrolments(int eventId)
        {
            var ev = await _context.Events.FindAsync(eventId);
            if (ev == null)
                return NotFound(new { message = "Event not found" });

            var organiserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
            if (ev.OrganiserID != organiserId)
                return StatusCode(403, new { message = "Not your event" });

            var enrolments = await _context.Enrolments
                .Include(e => e.Participant)
                .Include(e => e.Category)
                .Where(e => e.Category.EventID == eventId)
                .Select(e => new
                {
                    e.EnrolmentID,
                    ParticipantName = e.Participant.FullName,
                    e.Category.CategoryName,
                    e.EnrolmentDate,
                    e.Status,
                    e.PaymentStatus
                })
                .ToListAsync();

            return Ok(enrolments);
        }
    }

    public class CreateEnrolmentDto
    {
        public int CategoryId { get; set; }
    }

    public class UpdateEnrolmentStatusDto
    {
        public string Status { get; set; } = string.Empty;
    }
}