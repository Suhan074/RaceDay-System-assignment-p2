using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using RaceDayAPI.Data;
using RaceDayAPI.Models;

namespace RaceDayAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EventsController : ControllerBase
    {
        private readonly RaceDayDbContext _context;

        public EventsController(RaceDayDbContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Get all events (Public)
        /// </summary>
        [HttpGet]
        public async Task<IActionResult> GetAllEvents([FromQuery] string? status, [FromQuery] string? search)
        {
            var query = _context.Events
                .Include(e => e.Organiser)
                .Include(e => e.Categories)
                .AsQueryable();

            if (!string.IsNullOrEmpty(status))
                query = query.Where(e => e.Status == status);

            if (!string.IsNullOrEmpty(search))
                query = query.Where(e => e.EventName.Contains(search) || e.Location.Contains(search));

            var events = await query
                .Select(e => new
                {
                    e.EventID,
                    e.EventName,
                    e.Description,
                    e.EventDate,
                    e.Location,
                    e.Distance,
                    e.EventType,
                    e.MaxParticipants,
                    e.Status,
                    OrganiserName = e.Organiser.FullName,
                    CategoryCount = e.Categories.Count
                })
                .ToListAsync();

            return Ok(events);
        }

        /// <summary>
        /// Get event by ID (Public)
        /// </summary>
        [HttpGet("{id}")]
        public async Task<IActionResult> GetEvent(int id)
        {
            var ev = await _context.Events
                .Include(e => e.Organiser)
                .Include(e => e.Categories)
                .FirstOrDefaultAsync(e => e.EventID == id);

            if (ev == null)
                return NotFound(new { message = "Event not found" });

            return Ok(new
            {
                ev.EventID,
                ev.EventName,
                ev.Description,
                ev.EventDate,
                ev.Location,
                ev.Distance,
                ev.EventType,
                ev.MaxParticipants,
                ev.Status,
                OrganiserName = ev.Organiser.FullName,
                Categories = ev.Categories.Select(c => new
                {
                    c.CategoryID,
                    c.CategoryName,
                    c.MinAge,
                    c.MaxAge,
                    c.GenderRestriction
                })
            });
        }

        /// <summary>
        /// Create new event (Organiser only)
        /// </summary>
        [HttpPost]
        [Authorize(Roles = "Organiser")]
        public async Task<IActionResult> CreateEvent([FromBody] CreateEventDto dto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var organiserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");

            var ev = new Event
            {
                OrganiserID = organiserId,
                EventName = dto.EventName,
                Description = dto.Description,
                EventDate = dto.EventDate,
                Location = dto.Location,
                Distance = dto.Distance,
                EventType = dto.EventType,
                MaxParticipants = dto.MaxParticipants,
                Status = dto.Status ?? "Upcoming",
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };

            _context.Events.Add(ev);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetEvent), new { id = ev.EventID }, ev);
        }

        /// <summary>
        /// Update event (Organiser only)
        /// </summary>
        [HttpPut("{id}")]
        [Authorize(Roles = "Organiser")]
        public async Task<IActionResult> UpdateEvent(int id, [FromBody] CreateEventDto dto)
        {
            var ev = await _context.Events.FindAsync(id);
            if (ev == null)
                return NotFound(new { message = "Event not found" });

            var organiserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
            if (ev.OrganiserID != organiserId)
                return StatusCode(403, new { message = "Not your event" });

            ev.EventName = dto.EventName;
            ev.Description = dto.Description;
            ev.EventDate = dto.EventDate;
            ev.Location = dto.Location;
            ev.Distance = dto.Distance;
            ev.EventType = dto.EventType;
            ev.MaxParticipants = dto.MaxParticipants;
            ev.Status = dto.Status ?? ev.Status;
            ev.UpdatedAt = DateTime.UtcNow;

            await _context.SaveChangesAsync();
            return Ok(ev);
        }

        /// <summary>
        /// Delete event (Organiser only)
        /// </summary>
        [HttpDelete("{id}")]
        [Authorize(Roles = "Organiser")]
        public async Task<IActionResult> DeleteEvent(int id)
        {
            var ev = await _context.Events.FindAsync(id);
            if (ev == null)
                return NotFound(new { message = "Event not found" });

            var organiserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
            if (ev.OrganiserID != organiserId)
                return StatusCode(403, new { message = "Not your event" });

            _context.Events.Remove(ev);
            await _context.SaveChangesAsync();
            return NoContent();
        }

        /// <summary>
        /// Get categories for an event (Public)
        /// </summary>
        [HttpGet("{id}/categories")]
        public async Task<IActionResult> GetEventCategories(int id)
        {
            var categories = await _context.Categories
                .Where(c => c.EventID == id)
                .Select(c => new
                {
                    c.CategoryID,
                    c.CategoryName,
                    c.Description,
                    c.MinAge,
                    c.MaxAge,
                    c.GenderRestriction,
                    EnrolmentCount = c.Enrolments.Count
                })
                .ToListAsync();

            return Ok(categories);
        }

        /// <summary>
        /// Get all enrolments for an event (Organiser only)
        /// </summary>
        [HttpGet("{id}/enrolments")]
        [Authorize(Roles = "Organiser")]
        public async Task<IActionResult> GetEventEnrolments(int id)
        {
            var ev = await _context.Events.FindAsync(id);
            if (ev == null)
                return NotFound(new { message = "Event not found" });

            var organiserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
            if (ev.OrganiserID != organiserId)
                return StatusCode(403, new { message = "Not your event" });

            var enrolments = await _context.Enrolments
                .Include(e => e.Participant)
                .Include(e => e.Category)
                .Where(e => e.Category.EventID == id)
                .Select(e => new
                {
                    e.EnrolmentID,
                    ParticipantName = e.Participant.FullName,
                    ParticipantEmail = e.Participant.Email,
                    CategoryName = e.Category.CategoryName,
                    e.EnrolmentDate,
                    e.Status,
                    e.PaymentStatus
                })
                .ToListAsync();

            return Ok(enrolments);
        }
    }

    public class CreateEventDto
    {
        public string EventName { get; set; } = string.Empty;
        public string? Description { get; set; }
        public DateTime EventDate { get; set; }
        public string Location { get; set; } = string.Empty;
        public string Distance { get; set; } = string.Empty;
        public string EventType { get; set; } = "Run";
        public int MaxParticipants { get; set; }
        public string? Status { get; set; }
    }
}