using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using RaceDayAPI.Data;
using RaceDayAPI.Models;

namespace RaceDayAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class UsersController : ControllerBase
    {
        private readonly RaceDayDbContext _context;

        public UsersController(RaceDayDbContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Get current user's profile
        /// </summary>
        [HttpGet("profile")]
        public async Task<IActionResult> GetProfile()
        {
            var userId = GetCurrentUserId();
            var user = await _context.Users.FindAsync(userId);

            if (user == null)
                return NotFound(new { message = "User not found" });

            return Ok(new
            {
                user.UserID,
                user.Email,
                user.FullName,
                user.Role,
                user.CreatedAt
            });
        }

        /// <summary>
        /// Update current user's profile
        /// </summary>
        [HttpPut("profile")]
        public async Task<IActionResult> UpdateProfile([FromBody] UpdateProfileDto dto)
        {
            var userId = GetCurrentUserId();
            var user = await _context.Users.FindAsync(userId);

            if (user == null)
                return NotFound(new { message = "User not found" });

            // Check email uniqueness if email is being changed
            if (dto.Email != user.Email && _context.Users.Any(u => u.Email == dto.Email))
                return Conflict(new { message = "Email already in use" });

            user.FullName = dto.FullName ?? user.FullName;
            user.Email = dto.Email ?? user.Email;
            user.UpdatedAt = DateTime.UtcNow;

            await _context.SaveChangesAsync();

            return Ok(new { message = "Profile updated successfully" });
        }

        /// <summary>
        /// Get all enrolments for a specific user
        /// </summary>
        [HttpGet("{id}/enrolments")]
        public async Task<IActionResult> GetUserEnrolments(int id)
        {
            var currentUserId = GetCurrentUserId();
            var currentUserRole = GetCurrentUserRole();

            // Users can only view their own enrolments unless they are an organiser
            if (currentUserId != id && currentUserRole != "Organiser")
                return Forbidden();

            var enrolments = await _context.Enrolments
                .Include(e => e.Category)
                    .ThenInclude(c => c.Event)
                .Include(e => e.Result)
                .Where(e => e.ParticipantID == id)
                .Select(e => new
                {
                    e.EnrolmentID,
                    EventName = e.Category.Event.EventName,
                    CategoryName = e.Category.CategoryName,
                    e.EnrolmentDate,
                    e.Status,
                    e.PaymentStatus,
                    HasResult = e.Result != null
                })
                .ToListAsync();

            return Ok(enrolments);
        }

        /// <summary>
        /// Get all participants (Organiser only)
        /// </summary>
        [HttpGet("participants")]
        [Authorize(Roles = "Organiser")]
        public async Task<IActionResult> GetAllParticipants()
        {
            var participants = await _context.Users
                .Where(u => u.Role == "Participant")
                .Select(u => new
                {
                    u.UserID,
                    u.Email,
                    u.FullName,
                    EnrolmentCount = u.Enrolments.Count
                })
                .ToListAsync();

            return Ok(participants);
        }

        private int GetCurrentUserId()
        {
            return int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
        }

        private string GetCurrentUserRole()
        {
            return User.FindFirst(ClaimTypes.Role)?.Value ?? "";
        }

        private IActionResult Forbidden()
        {
            return StatusCode(StatusCodes.Status403Forbidden, new { message = "Access denied" });
        }
    }

    public class UpdateProfileDto
    {
        public string? FullName { get; set; }
        public string? Email { get; set; }
    }
}