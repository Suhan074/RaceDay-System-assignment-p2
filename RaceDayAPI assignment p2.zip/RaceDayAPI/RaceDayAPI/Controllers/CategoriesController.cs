using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using RaceDayAPI.Data;
using RaceDayAPI.Models;

namespace RaceDayAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoriesController : ControllerBase
    {
        private readonly RaceDayDbContext _context;

        public CategoriesController(RaceDayDbContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Get all categories (Public)
        /// </summary>
        [HttpGet]
        public async Task<IActionResult> GetAllCategories([FromQuery] int? eventId)
        {
            var query = _context.Categories
                .Include(c => c.Event)
                .AsQueryable();

            if (eventId.HasValue)
                query = query.Where(c => c.EventID == eventId.Value);

            var categories = await query
                .Select(c => new
                {
                    c.CategoryID,
                    c.CategoryName,
                    c.Description,
                    c.MinAge,
                    c.MaxAge,
                    c.GenderRestriction,
                    EventName = c.Event.EventName,
                    EventID = c.EventID
                })
                .ToListAsync();

            return Ok(categories);
        }

        /// <summary>
        /// Get category by ID (Public)
        /// </summary>
        [HttpGet("{id}")]
        public async Task<IActionResult> GetCategory(int id)
        {
            var category = await _context.Categories
                .Include(c => c.Event)
                .FirstOrDefaultAsync(c => c.CategoryID == id);

            if (category == null)
                return NotFound(new { message = "Category not found" });

            return Ok(category);
        }

        /// <summary>
        /// Create category for event (Organiser only)
        /// </summary>
        [HttpPost("/api/events/{eventId}/categories")]
        [Authorize(Roles = "Organiser")]
        public async Task<IActionResult> CreateCategory(int eventId, [FromBody] CreateCategoryDto dto)
        {
            var ev = await _context.Events.FindAsync(eventId);
            if (ev == null)
                return NotFound(new { message = "Event not found" });

            var organiserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
            if (ev.OrganiserID != organiserId)
                return StatusCode(403, new { message = "Not your event" });

            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var category = new Category
            {
                EventID = eventId,
                CategoryName = dto.CategoryName,
                Description = dto.Description,
                MinAge = dto.MinAge,
                MaxAge = dto.MaxAge,
                GenderRestriction = dto.GenderRestriction ?? "None",
                CreatedAt = DateTime.UtcNow
            };

            _context.Categories.Add(category);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetCategory), new { id = category.CategoryID }, category);
        }

        /// <summary>
        /// Update category (Organiser only)
        /// </summary>
        [HttpPut("{id}")]
        [Authorize(Roles = "Organiser")]
        public async Task<IActionResult> UpdateCategory(int id, [FromBody] CreateCategoryDto dto)
        {
            var category = await _context.Categories
                .Include(c => c.Event)
                .FirstOrDefaultAsync(c => c.CategoryID == id);

            if (category == null)
                return NotFound(new { message = "Category not found" });

            var organiserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
            if (category.Event.OrganiserID != organiserId)
                return StatusCode(403, new { message = "Not your event" });

            category.CategoryName = dto.CategoryName;
            category.Description = dto.Description;
            category.MinAge = dto.MinAge;
            category.MaxAge = dto.MaxAge;
            category.GenderRestriction = dto.GenderRestriction ?? category.GenderRestriction;

            await _context.SaveChangesAsync();
            return Ok(category);
        }

        /// <summary>
        /// Delete category (Organiser only)
        /// </summary>
        [HttpDelete("{id}")]
        [Authorize(Roles = "Organiser")]
        public async Task<IActionResult> DeleteCategory(int id)
        {
            var category = await _context.Categories
                .Include(c => c.Event)
                .Include(c => c.Enrolments)
                .FirstOrDefaultAsync(c => c.CategoryID == id);

            if (category == null)
                return NotFound(new { message = "Category not found" });

            var organiserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
            if (category.Event.OrganiserID != organiserId)
                return StatusCode(403, new { message = "Not your event" });

            if (category.Enrolments.Any())
                return Conflict(new { message = "Category has enrolments" });

            _context.Categories.Remove(category);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }

    public class CreateCategoryDto
    {
        public string CategoryName { get; set; } = string.Empty;
        public string? Description { get; set; }
        public int? MinAge { get; set; }
        public int? MaxAge { get; set; }
        public string? GenderRestriction { get; set; }
    }
}