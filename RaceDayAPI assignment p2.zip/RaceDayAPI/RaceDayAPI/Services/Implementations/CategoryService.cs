using Microsoft.EntityFrameworkCore;
using RaceDayAPI.Data;
using RaceDayAPI.DTOs.Categories;
using RaceDayAPI.Helpers;
using RaceDayAPI.Models;
using RaceDayAPI.Services.Interfaces;

namespace RaceDayAPI.Services.Implementations
{
    public class CategoryService : ICategoryService
    {
        private readonly RaceDayDbContext _context;

        public CategoryService(RaceDayDbContext context)
        {
            _context = context;
        }

        public async Task<List<CategoryListDto>> GetAllCategoriesAsync(int? eventId)
        {
            var query = _context.Categories
                .Include(c => c.Event)
                .AsQueryable();

            if (eventId.HasValue)
                query = query.Where(c => c.EventID == eventId.Value);

            return await query
                .Select(c => new CategoryListDto
                {
                    CategoryID = c.CategoryID,
                    CategoryName = c.CategoryName,
                    Description = c.Description,
                    MinAge = c.MinAge,
                    MaxAge = c.MaxAge,
                    GenderRestriction = c.GenderRestriction,
                    EventID = c.EventID,
                    EventName = c.Event.EventName,
                    EnrolmentCount = c.Enrolments.Count
                })
                .ToListAsync();
        }

        public async Task<CategoryDetailDto?> GetCategoryByIdAsync(int id)
        {
            var category = await _context.Categories
                .Include(c => c.Event)
                .FirstOrDefaultAsync(c => c.CategoryID == id);

            if (category == null) return null;

            return new CategoryDetailDto
            {
                CategoryID = category.CategoryID,
                CategoryName = category.CategoryName,
                Description = category.Description,
                MinAge = category.MinAge,
                MaxAge = category.MaxAge,
                GenderRestriction = category.GenderRestriction,
                EventID = category.EventID,
                EventName = category.Event.EventName,
                EnrolmentCount = await _context.Enrolments.CountAsync(e => e.CategoryID == id)
            };
        }

        public async Task<CategoryDetailDto> CreateCategoryAsync(int eventId, int organiserId, CreateCategoryDto dto)
        {
            var ev = await _context.Events.FindAsync(eventId);
            if (ev == null)
                throw new KeyNotFoundException("Event not found");

            if (ev.OrganiserID != organiserId)
                throw new UnauthorizedAccessException("Not your event");

            if (!string.IsNullOrEmpty(dto.GenderRestriction) &&
                !ValidationHelper.IsValidGenderRestriction(dto.GenderRestriction))
                throw new InvalidOperationException("Gender restriction must be None, Male, or Female");

            if (!ValidationHelper.IsValidAgeRange(dto.MinAge, dto.MaxAge))
                throw new InvalidOperationException("Invalid age range");

            var category = new Category
            {
                EventID = eventId,
                CategoryName = dto.CategoryName,
                Description = dto.Description,
                MinAge = dto.MinAge,
                MaxAge = dto.MaxAge,
                GenderRestriction = dto.GenderRestriction ?? "None",
                CreatedAt = DateTime.UtcNow
            };

            _context.Categories.Add(category);
            await _context.SaveChangesAsync();

            return (await GetCategoryByIdAsync(category.CategoryID))!;
        }

        public async Task<bool> UpdateCategoryAsync(int id, int organiserId, CreateCategoryDto dto)
        {
            var category = await _context.Categories
                .Include(c => c.Event)
                .FirstOrDefaultAsync(c => c.CategoryID == id);

            if (category == null) return false;

            if (category.Event.OrganiserID != organiserId)
                throw new UnauthorizedAccessException("Not your event");

            if (!string.IsNullOrEmpty(dto.GenderRestriction) &&
                !ValidationHelper.IsValidGenderRestriction(dto.GenderRestriction))
                throw new InvalidOperationException("Gender restriction must be None, Male, or Female");

            if (!ValidationHelper.IsValidAgeRange(dto.MinAge, dto.MaxAge))
                throw new InvalidOperationException("Invalid age range");

            category.CategoryName = dto.CategoryName;
            category.Description = dto.Description;
            category.MinAge = dto.MinAge;
            category.MaxAge = dto.MaxAge;
            category.GenderRestriction = dto.GenderRestriction ?? category.GenderRestriction;

            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> DeleteCategoryAsync(int id, int organiserId)
        {
            var category = await _context.Categories
                .Include(c => c.Event)
                .Include(c => c.Enrolments)
                .FirstOrDefaultAsync(c => c.CategoryID == id);

            if (category == null) return false;

            if (category.Event.OrganiserID != organiserId)
                throw new UnauthorizedAccessException("Not your event");

            if (category.Enrolments.Any())
                throw new InvalidOperationException("Cannot delete category with enrolments");

            _context.Categories.Remove(category);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<List<CategoryEnrolmentDto>> GetCategoryEnrolmentsAsync(int id, int organiserId)
        {
            var category = await _context.Categories
                .Include(c => c.Event)
                .FirstOrDefaultAsync(c => c.CategoryID == id);

            if (category == null)
                throw new KeyNotFoundException("Category not found");

            if (category.Event.OrganiserID != organiserId)
                throw new UnauthorizedAccessException("Not your event");

            return await _context.Enrolments
                .Include(e => e.Participant)
                .Where(e => e.CategoryID == id)
                .Select(e => new CategoryEnrolmentDto
                {
                    EnrolmentID = e.EnrolmentID,
                    ParticipantName = e.Participant.FullName,
                    ParticipantEmail = e.Participant.Email,
                    EnrolmentDate = e.EnrolmentDate,
                    Status = e.Status
                })
                .ToListAsync();
        }
    }
}