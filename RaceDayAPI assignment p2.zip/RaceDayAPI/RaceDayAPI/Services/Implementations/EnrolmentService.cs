using Microsoft.EntityFrameworkCore;
using RaceDayAPI.Data;
using RaceDayAPI.DTOs.Enrolments;
using RaceDayAPI.Helpers;
using RaceDayAPI.Models;
using RaceDayAPI.Services.Interfaces;

namespace RaceDayAPI.Services.Implementations
{
    public class EnrolmentService : IEnrolmentService
    {
        private readonly RaceDayDbContext _context;

        public EnrolmentService(RaceDayDbContext context)
        {
            _context = context;
        }

        public async Task<EnrolmentDto> CreateEnrolmentAsync(int participantId, CreateEnrolmentDto dto)
        {
            var category = await _context.Categories
                .Include(c => c.Event)
                .FirstOrDefaultAsync(c => c.CategoryID == dto.CategoryId);

            if (category == null)
                throw new KeyNotFoundException("Category not found");

            if (category.Event.Status == StatusConstants.EventStatus.Completed ||
                category.Event.Status == StatusConstants.EventStatus.Cancelled)
                throw new InvalidOperationException("Event is no longer accepting enrolments");

            if (await _context.Enrolments.AnyAsync(e =>
                e.ParticipantID == participantId && e.CategoryID == dto.CategoryId))
                throw new InvalidOperationException("Already enrolled in this category");

            var currentCount = await _context.Enrolments
                .CountAsync(e => e.Category.EventID == category.EventID &&
                                 e.Status != StatusConstants.EnrolmentStatus.Cancelled);

            if (currentCount >= category.Event.MaxParticipants)
                throw new InvalidOperationException("Event is full");

            var enrolment = new Enrolment
            {
                ParticipantID = participantId,
                CategoryID = dto.CategoryId,
                EnrolmentDate = DateTime.UtcNow,
                Status = StatusConstants.EnrolmentStatus.Pending,
                PaymentStatus = StatusConstants.PaymentStatus.Pending,
                UpdatedAt = DateTime.UtcNow
            };

            _context.Enrolments.Add(enrolment);
            await _context.SaveChangesAsync();

            return new EnrolmentDto
            {
                EnrolmentID = enrolment.EnrolmentID,
                ParticipantID = enrolment.ParticipantID,
                CategoryID = enrolment.CategoryID,
                EnrolmentDate = enrolment.EnrolmentDate,
                Status = enrolment.Status,
                PaymentStatus = enrolment.PaymentStatus
            };
        }

        public async Task<List<MyEnrolmentDto>> GetMyEnrolmentsAsync(int participantId)
        {
            return await _context.Enrolments
                .Include(e => e.Category)
                    .ThenInclude(c => c.Event)
                .Include(e => e.Result)
                .Where(e => e.ParticipantID == participantId)
                .Select(e => new MyEnrolmentDto
                {
                    EnrolmentID = e.EnrolmentID,
                    EventName = e.Category.Event.EventName,
                    EventDate = e.Category.Event.EventDate,
                    CategoryName = e.Category.CategoryName,
                    EnrolmentDate = e.EnrolmentDate,
                    Status = e.Status,
                    PaymentStatus = e.PaymentStatus,
                    HasResult = e.Result != null
                })
                .ToListAsync();
        }

        public async Task<EnrolmentDetailDto?> GetEnrolmentByIdAsync(int id, int userId, string role)
        {
            var enrolment = await _context.Enrolments
                .Include(e => e.Category)
                    .ThenInclude(c => c.Event)
                .Include(e => e.Participant)
                .FirstOrDefaultAsync(e => e.EnrolmentID == id);

            if (enrolment == null) return null;

            if (role != RoleConstants.Organiser && enrolment.ParticipantID != userId)
                throw new UnauthorizedAccessException("Access denied");

            return new EnrolmentDetailDto
            {
                EnrolmentID = enrolment.EnrolmentID,
                ParticipantID = enrolment.ParticipantID,
                ParticipantName = enrolment.Participant.FullName,
                EventName = enrolment.Category.Event.EventName,
                CategoryName = enrolment.Category.CategoryName,
                EnrolmentDate = enrolment.EnrolmentDate,
                Status = enrolment.Status,
                PaymentStatus = enrolment.PaymentStatus
            };
        }

        public async Task<bool> UpdateEnrolmentStatusAsync(int id, int organiserId, string status)
        {
            if (!ValidationHelper.IsValidEnrolmentStatus(status))
                throw new InvalidOperationException("Invalid enrolment status");

            var enrolment = await _context.Enrolments
                .Include(e => e.Category)
                    .ThenInclude(c => c.Event)
                .FirstOrDefaultAsync(e => e.EnrolmentID == id);

            if (enrolment == null) return false;

            if (enrolment.Category.Event.OrganiserID != organiserId)
                throw new UnauthorizedAccessException("Not your event");

            enrolment.Status = status;
            enrolment.UpdatedAt = DateTime.UtcNow;

            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> CancelEnrolmentAsync(int id, int participantId)
        {
            var enrolment = await _context.Enrolments.FindAsync(id);
            if (enrolment == null) return false;

            if (enrolment.ParticipantID != participantId)
                throw new UnauthorizedAccessException("Not your enrolment");

            if (enrolment.Status == StatusConstants.EnrolmentStatus.Confirmed)
                throw new InvalidOperationException("Cannot cancel confirmed enrolment");

            _context.Enrolments.Remove(enrolment);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<List<EventEnrolmentDto>> GetEventEnrolmentsAsync(int eventId, int organiserId)
        {
            var ev = await _context.Events.FindAsync(eventId);
            if (ev == null)
                throw new KeyNotFoundException("Event not found");

            if (ev.OrganiserID != organiserId)
                throw new UnauthorizedAccessException("Not your event");

            return await _context.Enrolments
                .Include(e => e.Participant)
                .Include(e => e.Category)
                .Where(e => e.Category.EventID == eventId)
                .Select(e => new EventEnrolmentDto
                {
                    EnrolmentID = e.EnrolmentID,
                    ParticipantName = e.Participant.FullName,
                    CategoryName = e.Category.CategoryName,
                    EnrolmentDate = e.EnrolmentDate,
                    Status = e.Status,
                    PaymentStatus = e.PaymentStatus
                })
                .ToListAsync();
        }
    }
}