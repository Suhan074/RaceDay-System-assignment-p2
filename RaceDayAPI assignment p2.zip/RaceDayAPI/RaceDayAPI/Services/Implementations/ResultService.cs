using Microsoft.EntityFrameworkCore;
using RaceDayAPI.Data;
using RaceDayAPI.DTOs.Results;
using RaceDayAPI.Helpers;
using RaceDayAPI.Models;
using RaceDayAPI.Services.Interfaces;

namespace RaceDayAPI.Services.Implementations
{
    public class ResultService : IResultService
    {
        private readonly RaceDayDbContext _context;

        public ResultService(RaceDayDbContext context)
        {
            _context = context;
        }

        public async Task<ResultDto> AddResultAsync(int organiserId, CreateResultDto dto)
        {
            var enrolment = await _context.Enrolments
                .Include(e => e.Category)
                    .ThenInclude(c => c.Event)
                .FirstOrDefaultAsync(e => e.EnrolmentID == dto.EnrolmentId);

            if (enrolment == null)
                throw new KeyNotFoundException("Enrolment not found");

            if (enrolment.Category.Event.OrganiserID != organiserId)
                throw new UnauthorizedAccessException("Not your event");

            if (await _context.Results.AnyAsync(r => r.EnrolmentID == dto.EnrolmentId))
                throw new InvalidOperationException("Result already exists for this enrolment");

            if (!string.IsNullOrEmpty(dto.Status) && !ValidationHelper.IsValidResultStatus(dto.Status))
                throw new InvalidOperationException("Invalid result status");

            var result = new Result
            {
                EnrolmentID = dto.EnrolmentId,
                FinishTime = dto.FinishTime,
                Position = dto.Position,
                Status = dto.Status ?? StatusConstants.ResultStatus.Finished,
                Notes = dto.Notes,
                UpdatedAt = DateTime.UtcNow
            };

            _context.Results.Add(result);
            await _context.SaveChangesAsync();

            return new ResultDto
            {
                ResultID = result.ResultID,
                EnrolmentID = result.EnrolmentID,
                FinishTime = result.FinishTime,
                Position = result.Position,
                Status = result.Status,
                Notes = result.Notes
            };
        }

        public async Task<List<MyResultDto>> GetMyResultsAsync(int participantId)
        {
            return await _context.Results
                .Include(r => r.Enrolment)
                    .ThenInclude(e => e.Category)
                        .ThenInclude(c => c.Event)
                .Where(r => r.Enrolment.ParticipantID == participantId)
                .Select(r => new MyResultDto
                {
                    ResultID = r.ResultID,
                    EventName = r.Enrolment.Category.Event.EventName,
                    CategoryName = r.Enrolment.Category.CategoryName,
                    FinishTime = r.FinishTime,
                    Position = r.Position,
                    Status = r.Status,
                    Notes = r.Notes
                })
                .ToListAsync();
        }

        public async Task<ResultDetailDto?> GetResultByIdAsync(int id, int userId, string role)
        {
            var result = await _context.Results
                .Include(r => r.Enrolment)
                    .ThenInclude(e => e.Participant)
                .Include(r => r.Enrolment)
                    .ThenInclude(e => e.Category)
                        .ThenInclude(c => c.Event)
                .FirstOrDefaultAsync(r => r.ResultID == id);

            if (result == null) return null;

            if (role != RoleConstants.Organiser && result.Enrolment.ParticipantID != userId)
                throw new UnauthorizedAccessException("Access denied");

            return MapToDetail(result);
        }

        public async Task<ResultDetailDto?> GetResultByEnrolmentAsync(int enrolmentId, int userId, string role)
        {
            var result = await _context.Results
                .Include(r => r.Enrolment)
                    .ThenInclude(e => e.Participant)
                .Include(r => r.Enrolment)
                    .ThenInclude(e => e.Category)
                        .ThenInclude(c => c.Event)
                .FirstOrDefaultAsync(r => r.EnrolmentID == enrolmentId);

            if (result == null) return null;

            if (role != RoleConstants.Organiser && result.Enrolment.ParticipantID != userId)
                throw new UnauthorizedAccessException("Access denied");

            return MapToDetail(result);
        }

        public async Task<bool> UpdateResultAsync(int id, int organiserId, UpdateResultDto dto)
        {
            var result = await _context.Results
                .Include(r => r.Enrolment)
                    .ThenInclude(e => e.Category)
                        .ThenInclude(c => c.Event)
                .FirstOrDefaultAsync(r => r.ResultID == id);

            if (result == null) return false;

            if (result.Enrolment.Category.Event.OrganiserID != organiserId)
                throw new UnauthorizedAccessException("Not your event");

            if (!string.IsNullOrEmpty(dto.Status) && !ValidationHelper.IsValidResultStatus(dto.Status))
                throw new InvalidOperationException("Invalid result status");

            if (dto.FinishTime.HasValue) result.FinishTime = dto.FinishTime;
            if (dto.Position.HasValue) result.Position = dto.Position;
            if (!string.IsNullOrEmpty(dto.Status)) result.Status = dto.Status;
            if (dto.Notes != null) result.Notes = dto.Notes;

            result.UpdatedAt = DateTime.UtcNow;
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> DeleteResultAsync(int id, int organiserId)
        {
            var result = await _context.Results
                .Include(r => r.Enrolment)
                    .ThenInclude(e => e.Category)
                        .ThenInclude(c => c.Event)
                .FirstOrDefaultAsync(r => r.ResultID == id);

            if (result == null) return false;

            if (result.Enrolment.Category.Event.OrganiserID != organiserId)
                throw new UnauthorizedAccessException("Not your event");

            _context.Results.Remove(result);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<List<EventResultDto>> GetEventResultsAsync(int eventId, int organiserId)
        {
            var ev = await _context.Events.FindAsync(eventId);
            if (ev == null)
                throw new KeyNotFoundException("Event not found");

            if (ev.OrganiserID != organiserId)
                throw new UnauthorizedAccessException("Not your event");

            return await _context.Results
                .Include(r => r.Enrolment)
                    .ThenInclude(e => e.Participant)
                .Include(r => r.Enrolment)
                    .ThenInclude(e => e.Category)
                .Where(r => r.Enrolment.Category.EventID == eventId)
                .Select(r => new EventResultDto
                {
                    ResultID = r.ResultID,
                    ParticipantName = r.Enrolment.Participant.FullName,
                    CategoryName = r.Enrolment.Category.CategoryName,
                    FinishTime = r.FinishTime,
                    Position = r.Position,
                    Status = r.Status,
                    Notes = r.Notes
                })
                .ToListAsync();
        }

        public async Task<List<LeaderboardDto>> GetLeaderboardAsync(int eventId)
        {
            return await _context.Results
                .Include(r => r.Enrolment)
                    .ThenInclude(e => e.Participant)
                .Include(r => r.Enrolment)
                    .ThenInclude(e => e.Category)
                .Where(r => r.Enrolment.Category.EventID == eventId
                         && r.Status == StatusConstants.ResultStatus.Finished
                         && r.Position != null)
                .OrderBy(r => r.Position)
                .Select(r => new LeaderboardDto
                {
                    Position = r.Position,
                    ParticipantName = r.Enrolment.Participant.FullName,
                    CategoryName = r.Enrolment.Category.CategoryName,
                    FinishTime = r.FinishTime
                })
                .ToListAsync();
        }

        private static ResultDetailDto MapToDetail(Result r)
        {
            return new ResultDetailDto
            {
                ResultID = r.ResultID,
                EnrolmentID = r.EnrolmentID,
                ParticipantName = r.Enrolment.Participant.FullName,
                EventName = r.Enrolment.Category.Event.EventName,
                CategoryName = r.Enrolment.Category.CategoryName,
                FinishTime = r.FinishTime,
                Position = r.Position,
                Status = r.Status,
                Notes = r.Notes
            };
        }
    }
}