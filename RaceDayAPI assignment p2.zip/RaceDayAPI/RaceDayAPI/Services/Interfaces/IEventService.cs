using RaceDayAPI.DTOs.Categories;
using RaceDayAPI.DTOs.Events;

namespace RaceDayAPI.Services.Interfaces
{
    public interface IEventService
    {
        Task<List<EventListDto>> GetAllEventsAsync(string? status, string? search);
        Task<EventDetailDto?> GetEventByIdAsync(int id);
        Task<EventDetailDto> CreateEventAsync(int organiserId, CreateEventDto dto);
        Task<bool> UpdateEventAsync(int id, int organiserId, CreateEventDto dto);
        Task<bool> DeleteEventAsync(int id, int organiserId);
        Task<List<CategoryListDto>> GetEventCategoriesAsync(int eventId);
        Task<List<EventEnrolmentDto>> GetEventEnrolmentsAsync(int eventId, int organiserId);
        Task<bool> IsEventOwnerAsync(int eventId, int organiserId);
    }
}