using RaceDayAPI.DTOs.Auth;

namespace RaceDayAPI.Services.Interfaces
{
    public interface IAuthService
    {
        Task<AuthResponseDto> RegisterAsync(RegisterDto dto);
        Task<AuthResponseDto> LoginAsync(LoginDto dto);
        Task<bool> EmailExistsAsync(string email);
    }
}