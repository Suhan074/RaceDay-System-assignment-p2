using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RaceDayAPI.Models
{
    /// <summary>
    /// Links a Participant to a Category (their enrolment/sign-up)
    /// </summary>
    public class Enrolment
    {
        [Key]
        public int EnrolmentID { get; set; }

        [Required]
        public int ParticipantID { get; set; }

        [Required]
        public int CategoryID { get; set; }

        public DateTime EnrolmentDate { get; set; } = DateTime.UtcNow;

        [Required]
        [MaxLength(50)]
        public string Status { get; set; } = "Pending"; // "Pending", "Confirmed", "Cancelled"

        [Required]
        [MaxLength(50)]
        public string PaymentStatus { get; set; } = "Pending"; // "Pending", "Paid", "Refunded"

        public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;

        // Navigation Properties
        [ForeignKey(nameof(ParticipantID))]
        public User Participant { get; set; } = null!;

        [ForeignKey(nameof(CategoryID))]
        public Category Category { get; set; } = null!;

        public Result? Result { get; set; }
    }
}