using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RaceDayAPI.Models
{
    /// <summary>
    /// Represents a race event created by an Organiser
    /// </summary>
    public class Event
    {
        [Key]
        public int EventID { get; set; }

        [Required]
        public int OrganiserID { get; set; }

        [Required]
        [MaxLength(255)]
        public string EventName { get; set; } = string.Empty;

        public string? Description { get; set; }

        [Required]
        public DateTime EventDate { get; set; }

        [Required]
        [MaxLength(255)]
        public string Location { get; set; } = string.Empty;

        [Required]
        [MaxLength(50)]
        public string Distance { get; set; } = string.Empty; // e.g., "5km", "10km", "42.2km"

        [Required]
        [MaxLength(50)]
        public string EventType { get; set; } = "Run"; // "Run", "Walk", "Cycle"

        [Required]
        public int MaxParticipants { get; set; }

        [Required]
        [MaxLength(50)]
        public string Status { get; set; } = "Upcoming"; // "Upcoming", "Ongoing", "Completed", "Cancelled"

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;

        // Navigation Properties
        [ForeignKey(nameof(OrganiserID))]
        public User Organiser { get; set; } = null!;

        public ICollection<Category> Categories { get; set; } = new List<Category>();
    }
}