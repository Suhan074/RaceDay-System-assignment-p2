namespace RaceDayAPI.DTOs.Enrolments
{
    /// <summary>
    /// Response returned when a Participant views their own enrolments
    /// </summary>
    public class MyEnrolmentDto
    {
        /// <summary>
        /// Unique enrolment ID
        /// </summary>
        public int EnrolmentID { get; set; }

        /// <summary>
        /// Name of the event
        /// </summary>
        public string EventName { get; set; } = string.Empty;

        /// <summary>
        /// When the event takes place
        /// </summary>
        public DateTime EventDate { get; set; }

        /// <summary>
        /// Name of the category the participant is enrolled in
        /// </summary>
        public string CategoryName { get; set; } = string.Empty;

        /// <summary>
        /// When the participant enrolled
        /// </summary>
        public DateTime EnrolmentDate { get; set; }

        /// <summary>
        /// Enrolment status: "Pending", "Confirmed", or "Cancelled"
        /// </summary>
        public string Status { get; set; } = string.Empty;

        /// <summary>
        /// Payment status: "Pending", "Paid", or "Refunded"
        /// </summary>
        public string PaymentStatus { get; set; } = string.Empty;

        /// <summary>
        /// Whether a result has been recorded for this enrolment
        /// </summary>
        public bool HasResult { get; set; }
    }
}