namespace RaceDayAPI.DTOs.Enrolments
{
    /// <summary>
    /// Response returned after a participant successfully enrols
    /// </summary>
    public class EnrolmentDto
    {
        /// <summary>
        /// Unique enrolment ID
        /// </summary>
        public int EnrolmentID { get; set; }

        /// <summary>
        /// ID of the participant who enrolled
        /// </summary>
        public int ParticipantID { get; set; }

        /// <summary>
        /// ID of the category enrolled in
        /// </summary>
        public int CategoryID { get; set; }

        /// <summary>
        /// When the participant enrolled
        /// </summary>
        public DateTime EnrolmentDate { get; set; }

        /// <summary>
        /// Enrolment status: "Pending", "Confirmed", or "Cancelled"
        /// </summary>
        public string Status { get; set; } = string.Empty;

        /// <summary>
        /// Payment status: "Pending", "Paid", or "Refunded"
        /// </summary>
        public string PaymentStatus { get; set; } = string.Empty;
    }
}