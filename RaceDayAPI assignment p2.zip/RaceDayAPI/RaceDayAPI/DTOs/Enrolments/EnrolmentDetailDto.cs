namespace RaceDayAPI.DTOs.Enrolments
{
    /// <summary>
    /// Response returned when viewing details of a single enrolment
    /// </summary>
    public class EnrolmentDetailDto
    {
        /// <summary>
        /// Unique enrolment ID
        /// </summary>
        public int EnrolmentID { get; set; }

        /// <summary>
        /// ID of the participant
        /// </summary>
        public int ParticipantID { get; set; }

        /// <summary>
        /// Full name of the participant
        /// </summary>
        public string ParticipantName { get; set; } = string.Empty;

        /// <summary>
        /// Name of the event
        /// </summary>
        public string EventName { get; set; } = string.Empty;

        /// <summary>
        /// Name of the category
        /// </summary>
        public string CategoryName { get; set; } = string.Empty;

        /// <summary>
        /// When the participant enrolled
        /// </summary>
        public DateTime EnrolmentDate { get; set; }

        /// <summary>
        /// Enrolment status: "Pending", "Confirmed", or "Cancelled"
        /// </summary>
        public string Status { get; set; } = string.Empty;

        /// <summary>
        /// Payment status: "Pending", "Paid", or "Refunded"
        /// </summary>
        public string PaymentStatus { get; set; } = string.Empty;
    }
}