namespace RaceDayAPI.DTOs.Categories
{
    /// <summary>
    /// Response returned when listing all enrolments for a category
    /// (Organiser view)
    /// </summary>
    public class CategoryEnrolmentDto
    {
        /// <summary>
        /// Unique enrolment ID
        /// </summary>
        public int EnrolmentID { get; set; }

        /// <summary>
        /// Full name of the participant
        /// </summary>
        public string ParticipantName { get; set; } = string.Empty;

        /// <summary>
        /// Email of the participant
        /// </summary>
        public string ParticipantEmail { get; set; } = string.Empty;

        /// <summary>
        /// When the participant enrolled
        /// </summary>
        public DateTime EnrolmentDate { get; set; }

        /// <summary>
        /// Enrolment status: "Pending", "Confirmed", or "Cancelled"
        /// </summary>
        public string Status { get; set; } = string.Empty;
    }
}