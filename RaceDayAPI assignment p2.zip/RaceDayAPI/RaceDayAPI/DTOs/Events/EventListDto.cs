namespace RaceDayAPI.DTOs.Events
{
    /// <summary>
    /// Response returned when listing events (summary info only)
    /// </summary>
    public class EventListDto
    {
        /// <summary>
        /// Unique event ID
        /// </summary>
        public int EventID { get; set; }

        /// <summary>
        /// Name of the event
        /// </summary>
        public string EventName { get; set; } = string.Empty;

        /// <summary>
        /// Short description of the event
        /// </summary>
        public string? Description { get; set; }

        /// <summary>
        /// When the event will take place
        /// </summary>
        public DateTime EventDate { get; set; }

        /// <summary>
        /// Where the event will take place
        /// </summary>
        public string Location { get; set; } = string.Empty;

        /// <summary>
        /// Distance of the event
        /// </summary>
        public string Distance { get; set; } = string.Empty;

        /// <summary>
        /// Type of event: "Run", "Walk", or "Cycle"
        /// </summary>
        public string EventType { get; set; } = string.Empty;

        /// <summary>
        /// Maximum number of participants allowed
        /// </summary>
        public int MaxParticipants { get; set; }

        /// <summary>
        /// Event status
        /// </summary>
        public string Status { get; set; } = string.Empty;

        /// <summary>
        /// Full name of the Organiser who created the event
        /// </summary>
        public string OrganiserName { get; set; } = string.Empty;

        /// <summary>
        /// Number of categories in this event
        /// </summary>
        public int CategoryCount { get; set; }
    }
}