using System.ComponentModel.DataAnnotations;

namespace RaceDayAPI.DTOs.Auth
{
    /// <summary>
    /// Data sent by a user to register a new account
    /// </summary>
    public class RegisterDto
    {
        /// <summary>
        /// User's email address (must be unique)
        /// </summary>
        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Invalid email format")]
        [MaxLength(255, ErrorMessage = "Email cannot exceed 255 characters")]
        public string Email { get; set; } = string.Empty;

        /// <summary>
        /// User's password (must be at least 8 characters with uppercase, lowercase, and a number)
        /// </summary>
        [Required(ErrorMessage = "Password is required")]
        [MinLength(8, ErrorMessage = "Password must be at least 8 characters")]
        [MaxLength(100, ErrorMessage = "Password cannot exceed 100 characters")]
        public string Password { get; set; } = string.Empty;

        /// <summary>
        /// User's full name
        /// </summary>
        [Required(ErrorMessage = "Full name is required")]
        [MaxLength(255, ErrorMessage = "Full name cannot exceed 255 characters")]
        [MinLength(2, ErrorMessage = "Full name must be at least 2 characters")]
        public string FullName { get; set; } = string.Empty;

        /// <summary>
        /// User's role: "Organiser" or "Participant"
        /// </summary>
        [Required(ErrorMessage = "Role is required")]
        [RegularExpression("^(Organiser|Participant)$",
            ErrorMessage = "Role must be either 'Organiser' or 'Participant'")]
        public string Role { get; set; } = string.Empty;
    }
}