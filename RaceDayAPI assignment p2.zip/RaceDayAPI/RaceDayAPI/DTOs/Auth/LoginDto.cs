using System.ComponentModel.DataAnnotations;

namespace RaceDayAPI.DTOs.Auth
{
    /// <summary>
    /// Data sent by a user to log in
    /// </summary>
    public class LoginDto
    {
        /// <summary>
        /// Registered email address
        /// </summary>
        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Invalid email format")]
        public string Email { get; set; } = string.Empty;

        /// <summary>
        /// User's password
        /// </summary>
        [Required(ErrorMessage = "Password is required")]
        public string Password { get; set; } = string.Empty;
    }
}