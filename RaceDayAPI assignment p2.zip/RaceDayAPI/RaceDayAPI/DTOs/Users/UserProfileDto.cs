namespace RaceDayAPI.DTOs.Users
{
    /// <summary>
    /// Response returned when getting a user's profile
    /// </summary>
    public class UserProfileDto
    {
        /// <summary>
        /// Unique user ID
        /// </summary>
        public int UserID { get; set; }

        /// <summary>
        /// User's email address
        /// </summary>
        public string Email { get; set; } = string.Empty;

        /// <summary>
        /// User's full name
        /// </summary>
        public string FullName { get; set; } = string.Empty;

        /// <summary>
        /// User's role: "Organiser" or "Participant"
        /// </summary>
        public string Role { get; set; } = string.Empty;

        /// <summary>
        /// When the account was created
        /// </summary>
        public DateTime CreatedAt { get; set; }
    }
}