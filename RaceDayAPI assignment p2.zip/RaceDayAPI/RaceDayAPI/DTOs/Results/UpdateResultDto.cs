using System.ComponentModel.DataAnnotations;

namespace RaceDayAPI.DTOs.Results
{
    /// <summary>
    /// Data sent by an Organiser to update an existing result
    /// </summary>
    public class UpdateResultDto
    {
        /// <summary>
        /// Updated race finish time (optional)
        /// </summary>
        public TimeSpan? FinishTime { get; set; }

        /// <summary>
        /// Updated position/ranking (optional)
        /// </summary>
        [Range(1, 100000, ErrorMessage = "Position must be a positive number")]
        public int? Position { get; set; }

        /// <summary>
        /// Updated status: "DNS", "DNF", "Finished", or "Disqualified" (optional)
        /// </summary>
        [RegularExpression("^(DNS|DNF|Finished|Disqualified)$",
            ErrorMessage = "Status must be 'DNS', 'DNF', 'Finished', or 'Disqualified'")]
        public string? Status { get; set; }

        /// <summary>
        /// Updated notes (optional)
        /// </summary>
        [MaxLength(1000, ErrorMessage = "Notes cannot exceed 1000 characters")]
        public string? Notes { get; set; }
    }
}