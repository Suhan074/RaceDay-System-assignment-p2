namespace RaceDayAPI.DTOs.Results
{
    /// <summary>
    /// Response returned when viewing details of a single result
    /// </summary>
    public class ResultDetailDto
    {
        /// <summary>
        /// Unique result ID
        /// </summary>
        public int ResultID { get; set; }

        /// <summary>
        /// ID of the enrolment
        /// </summary>
        public int EnrolmentID { get; set; }

        /// <summary>
        /// Full name of the participant
        /// </summary>
        public string ParticipantName { get; set; } = string.Empty;

        /// <summary>
        /// Name of the event
        /// </summary>
        public string EventName { get; set; } = string.Empty;

        /// <summary>
        /// Name of the category
        /// </summary>
        public string CategoryName { get; set; } = string.Empty;

        /// <summary>
        /// Race finish time
        /// </summary>
        public TimeSpan? FinishTime { get; set; }

        /// <summary>
        /// Final position/ranking
        /// </summary>
        public int? Position { get; set; }

        /// <summary>
        /// Result status: "DNS", "DNF", "Finished", or "Disqualified"
        /// </summary>
        public string Status { get; set; } = string.Empty;

        /// <summary>
        /// Optional notes about the result
        /// </summary>
        public string? Notes { get; set; }
    }
}