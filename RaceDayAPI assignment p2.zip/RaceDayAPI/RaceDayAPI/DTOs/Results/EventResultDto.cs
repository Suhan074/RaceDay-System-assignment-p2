namespace RaceDayAPI.DTOs.Results
{
    /// <summary>
    /// Response returned when an Organiser views all results for an event
    /// </summary>
    public class EventResultDto
    {
        /// <summary>
        /// Unique result ID
        /// </summary>
        public int ResultID { get; set; }

        /// <summary>
        /// Full name of the participant
        /// </summary>
        public string ParticipantName { get; set; } = string.Empty;

        /// <summary>
        /// Category the participant competed in
        /// </summary>
        public string CategoryName { get; set; } = string.Empty;

        /// <summary>
        /// Race finish time
        /// </summary>
        public TimeSpan? FinishTime { get; set; }

        /// <summary>
        /// Final position/ranking
        /// </summary>
        public int? Position { get; set; }

        /// <summary>
        /// Result status: "DNS", "DNF", "Finished", or "Disqualified"
        /// </summary>
        public string Status { get; set; } = string.Empty;

        /// <summary>
        /// Optional notes about the result
        /// </summary>
        public string? Notes { get; set; }
    }
}