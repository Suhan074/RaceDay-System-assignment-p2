namespace RaceDayAPI.DTOs.Results
{
    /// <summary>
    /// Basic response returned after creating a result
    /// </summary>
    public class ResultDto
    {
        /// <summary>
        /// Unique result ID
        /// </summary>
        public int ResultID { get; set; }

        /// <summary>
        /// ID of the enrolment this result belongs to
        /// </summary>
        public int EnrolmentID { get; set; }

        /// <summary>
        /// Race finish time
        /// </summary>
        public TimeSpan? FinishTime { get; set; }

        /// <summary>
        /// Final position/ranking
        /// </summary>
        public int? Position { get; set; }

        /// <summary>
        /// Result status: "DNS", "DNF", "Finished", or "Disqualified"
        /// </summary>
        public string Status { get; set; } = string.Empty;

        /// <summary>
        /// Optional notes about the result
        /// </summary>
        public string? Notes { get; set; }
    }
}